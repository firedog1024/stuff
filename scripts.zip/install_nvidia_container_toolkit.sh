# install the NVidia container toolkit to allow containers access to the GPU resources

# install curl
sudo dnf install -y curl

# pull down the NVidia container toolkit repository information and add to known repos
curl -s -L https://nvidia.github.io/libnvidia-container/stable/rpm/nvidia-container-toolkit.repo | sudo tee /etc/yum.repos.d/nvidia-container-toolkit.repo

# install the NVidia toolkit from the package repository
export NVIDIA_CONTAINER_TOOLKIT_VERSION=1.18.2-1
sudo dnf install -y \
    nvidia-container-toolkit-${NVIDIA_CONTAINER_TOOLKIT_VERSION} \
    nvidia-container-toolkit-base-${NVIDIA_CONTAINER_TOOLKIT_VERSION} \
    libnvidia-container-tools-${NVIDIA_CONTAINER_TOOLKIT_VERSION} \
    libnvidia-container1-${NVIDIA_CONTAINER_TOOLKIT_VERSION}

# configure docker to use the NVidia container toolkit
sudo nvidia-ctk runtime configure --runtime=docker

# restart docker to pick up the change
sudo systemctl restart docker

# run a test container to make sure the install worked.
# The container should run nvidia-smi if everything is installed correctly
sudo docker run --rm --runtime=nvidia --gpus all ubuntu nvidia-smi
