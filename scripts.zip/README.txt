To install everything needed to run the inference engine containers.  On AWS EC2 Amazon Linuc 2023 VM's 
run these steps after issuing the command: sudo -s

1. Install the NVidia GPU drivers, may require a reboot but seems ok without on Amazon Linux 2023
   - Note: this is pretty slow especially later stages around step 178/179

   command: install_nvidia_drivers.sh

2. Install the NVidia Container Toolkit to allow GPU utilization in containers

   command: install_nvidia_container_toolkit.sh

3. Pull containers from Docker Hub (temporary solution) and start them under Docker. 
   Will need to login to Docker Hub as part of the script to pull the conatiners
   - Note: it's going to pull a large amount of large images this will take a while

   command: install_and_start_amd_containers.sh

4. To monitor GPU utilization you can use nvtop by building from source with this script.  Alternatively
   you can use nvidia-smi with command: watch -n 1 nvidia-smi

   command: install_nvtop.sh

5. Do a quick smoke test to make sure everything is running by sending in 500 AMD inference requests from the client to the engine service

   command: run_client_test.sh

