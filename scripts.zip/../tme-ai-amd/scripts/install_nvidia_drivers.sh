# install the NVidia drivers on Amazon Linux 2023

# install wget
sudo dnf install wget -y

# install kernel dependencies
sudo dnf install kernel-devel-$(uname -r) kernel-headers-$(uname -r) -y

# pull the driver down from NVidia
sudo wget https://us.download.nvidia.com/tesla/590.48.01/nvidia-driver-local-repo-amzn2023-590.48.01-1.0-1.x86_64.rpm

# install the driver from the local file
sudo rpm --install nvidia-driver-local-repo-amzn2023-590.48.01-1.0-1.x86_64.rpm
sudo dnf module install nvidia-driver:latest/default -y

# install the open drivers
sudo dnf module enable nvidia-driver:open-dkms
sudo dnf install nvidia-open -y

# clean up
rm nvidia-driver-local-repo-amzn2023-590.48.01-1.0-1.x86_64.rpm 

# a reboot might be necessary here but check to see if nvidia-smi works and shows the GPU,
# if so no need to do a reboot
# sudo reboot now


# to test if the drivers are installed run nvidia-smi and see the driver and CUDA version
# nvidia-smi

