# build and install nvtop so we can monitor the GPU easily

# install dependencies needed to build nvtop
sudo dnf install systemd-devel libudev-devel gcc cmake pkgconfig ncurses-devel gcc-c++ libdrm-devel -y

# pull nvtop source from github
git clone https://github.com/Syllo/nvtop.git

# build nvtop
cd nvtop
mkdir build && cd build
cmake .. -DNVML_RETRIEVE_HEADER_ONLINE=True -DAMDGPU_SUPPORT=OFF -DINTEL_SUPPORT=OFF -DMSM_SUPPORT=OFF -DPANFROST_SUPPORT=OFF -DPANTHOR_SUPPORT=OFF
make

# install the nvtop executable
sudo make install

# cleanup
cd ../..
rm -rf nvtop

# test the command works
nvtop
