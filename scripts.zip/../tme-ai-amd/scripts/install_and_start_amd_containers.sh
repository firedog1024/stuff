# install and start the containers needed for the Voice Media AMD solution

# install docker-compose command as not on AL2023 by default
sudo curl -SL https://github.com/docker/compose/releases/latest/download/docker-compose-linux-$(uname -m) -o /usr/libexec/docker/cli-plugins/docker-compose
sudo chmod +x /usr/libexec/docker/cli-plugins/docker-compose

# login to Docker Hub (temporary solution for testing only)
sudo docker login

# pull and start the containers for the inference service
sudo docker compose -f ../docker-compose-microservices-aws.yml -p tme-ai-amd up -d

# pull and start the containers for the client test
sudo docker compose -f ../docker-compose-aws-client.yml -p tme-ai-amd up -d

# check if containers are started, should see 5 containers
echo "**** Should see FIVE containers running now ****"
sudo docker ps | grep tme-

