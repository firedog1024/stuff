sudo docker stats tme-ai-amd-client-aws tme-inference-aws tme-audio-ingestion-aws tme-preprocessing-aws tme-redis-aws
