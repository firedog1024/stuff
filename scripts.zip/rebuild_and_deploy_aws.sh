#!/bin/bash
set -e

echo "======================================"
echo "Rebuilding and Deploying AWS Services"
echo "======================================"
echo ""

# Stop existing services
echo "Step 1: Stopping existing services..."
docker-compose -f docker-compose-microservices-aws.yml -p tme-ai-amd down
docker-compose -f docker-compose-aws-client.yml -p tme-ai-amd down
echo "✓ Services stopped"
echo ""

# Clean up Redis data volume (remove accumulated messages from memory leak)
echo "Step 2: Cleaning up Redis data volume..."
docker volume rm tme-ai-amd_redis-data-aws 2>/dev/null || echo "Volume already removed or doesn't exist"
echo "✓ Redis data cleaned"
echo ""

# Build microservices containers
echo "Step 3: Building microservices containers..."
docker-compose -f docker-compose-microservices-aws.yml -p tme-ai-amd build
echo "✓ Microservices containers built"
echo ""

# Build client container
echo "Step 4: Building client container..."
docker-compose -f docker-compose-aws-client.yml -p tme-ai-amd build
echo "✓ Client container built"
echo ""

# Start microservices
echo "Step 5: Starting microservices..."
docker-compose -f docker-compose-microservices-aws.yml -p tme-ai-amd up -d
echo "✓ Microservices started"
echo ""

# Wait for services to be ready
echo "Step 6: Waiting for services to be ready..."
sleep 10
echo "✓ Services should be ready"
echo ""

# Start client
echo "Step 7: Starting client container..."
docker-compose -f docker-compose-aws-client.yml -p tme-ai-amd up -d
echo "✓ Client started"
echo ""

# Show running containers
echo "Step 8: Verifying deployment..."
docker ps --filter "name=tme" --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"
echo ""

# Check Redis memory
echo "Step 9: Checking Redis memory usage..."
docker exec tme-redis-aws redis-cli INFO memory | grep used_memory_human
echo ""

# Check queue lengths
echo "Step 10: Checking queue lengths..."
echo "request_queue length: $(docker exec tme-redis-aws redis-cli XLEN request_queue)"
echo "inference_queue length: $(docker exec tme-redis-aws redis-cli XLEN inference_queue)"
echo ""

echo "======================================"
echo "✓ Deployment Complete!"
echo "======================================"
echo ""
echo "Run a test with:"
echo "docker exec tme-ai-amd-client-aws python3.13t client/async_client_test.py \\"
echo "  --hosts tme-audio-ingestion-aws:4444 \\"
echo "  --file /app/pcm16/2012051365_20250821_133723.wav \\"
echo "  --total-requests 500 --submit-threads 4 --get-threads 4"
echo ""
