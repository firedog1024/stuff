# install and start the containers needed for the Voice Media AMD solution

# login to Docker Hub (temporary solution for testing only)
sudo docker login

# pull and start the containers for the inference service
sudo docker-compose -f ../docker-compose-microservices-aws.yml -p tme-ai-amd up -d

# pull and start the containers for the client test
sudo docker-compose -f ../docker-compose-aws-client.yml -p tme-ai-amd up -d

# check if containers are started, should see 5 containers
echo "**** Should see FIVE containers running now ****"
sudo docker ps | grep tme-

