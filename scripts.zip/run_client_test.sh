#!/bin/bash

# run a quick test to make sure everything is running correctly
# 500 requests sent to the inference engine.  First run will be slow as model is pulled and loaded

req_count="500"

if [ $# -eq 0 ]
  then
    echo "No arguments supplied defaulting to $req_count requests, please wait ..."
  else
    req_count=$1
    echo "Running $req_count requests, please wait ..."
fi

sudo docker exec tme-ai-amd-client-aws python3.13t client/async_client_test.py \
  --hosts tme-audio-ingestion-aws:4444 \
  --file /app/pcm16/2012051365_20250821_133723.wav \
  --total-requests $req_count \
  --submit-threads 2 \
  --get-threads 2

sudo docker exec tme-ai-amd-client-aws python3.13t client/async_client_test.py \
  --hosts tme-audio-ingestion-aws:4444 \
  --file /app/pcm16/2012051365_20250821_133723.wav \
  --total-requests 1000 \
  --submit-threads 2 \
  --get-threads 2 > output.txt & nvtop